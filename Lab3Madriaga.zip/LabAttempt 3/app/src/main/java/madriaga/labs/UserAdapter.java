package madriaga.labs;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import io.realm.OrderedRealmCollection;
import io.realm.RealmRecyclerViewAdapter;

public class UserAdapter extends RealmRecyclerViewAdapter<User, UserAdapter.ViewHolder> {

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView una;
        TextView upa;
        Button editr;
        Button del;

        public ViewHolder(View item)
        {
            super(item);

            una = item.findViewById(R.id.una);
            upa = item.findViewById(R.id.upa);
            editr = item.findViewById(R.id.editr);
            del = item.findViewById(R.id.del);
        }
    }
    Admin activity;

    public UserAdapter(Admin activity, @Nullable OrderedRealmCollection<User> data, boolean autoUpdate) {
        super(data, autoUpdate);
        this.activity = activity;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View v = activity.getLayoutInflater().inflate(R.layout.rowslayout, parent, false);

        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
        User h = getItem(position);

        holder.una.setText(h.getUsernames());
        holder.upa.setText(h.getPasswords());

        holder.del.setTag(h);
        holder.del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.delUser((User) view.getTag());
            }
        });

        holder.editr.setTag(h);
        holder.editr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.editrUser((User) view.getTag());
            }
        });

    }








}


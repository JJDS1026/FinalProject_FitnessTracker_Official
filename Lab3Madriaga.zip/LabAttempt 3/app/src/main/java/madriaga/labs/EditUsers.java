package madriaga.labs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.Click;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.annotations.ViewById;

import java.util.UUID;

import io.realm.Realm;
import io.realm.RealmResults;

@EActivity
public class EditUsers extends AppCompatActivity {
    /*@ViewById
    TextView uuid;*/
    @ViewById
    EditText usernameed;
    @ViewById
    EditText userpassworded;
    @ViewById
    EditText regpassconfirmed;
    @ViewById
    Button saveed;
    @ViewById
    Button canceled;
    Realm realm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_users);
    }

    @AfterViews
    public void init()
    {
        realm = Realm.getDefaultInstance();
        SharedPreferences info = getSharedPreferences("data", 0);
        String welc = info.getString("UUIDS", "");

        realm = Realm.getDefaultInstance();
        RealmResults<User> list = realm.where(User.class).findAll();
        User id =  realm.where(User.class).equalTo("uuid", welc).findFirst();
        String nem = id.getUsernames();
        String pes = id.getPasswords();


        User newUser = realm.where(User.class).equalTo("uuid", welc).findFirst();

        if (newUser!=null)
        {
            usernameed.setText(nem);
            userpassworded.setText(pes);
            regpassconfirmed.setText(pes);
        }

    }

    public void onDestroy() {
        super.onDestroy();

        if (!realm.isClosed()) {
            realm.close();
        }
    }

    @Click
    public void saveed()
    {
        String user = usernameed.getText().toString();
        String pass = userpassworded.getText().toString();
        String pass2 = regpassconfirmed.getText().toString();
        realm = Realm.getDefaultInstance();
        RealmResults<User> list = realm.where(User.class).findAll();
        User ename =  realm.where(User.class).equalTo("usernames", usernameed.getText().toString()).findFirst();


        if (user.equals("")) {
            Toast.makeText(this, "Name must not be blank", Toast.LENGTH_SHORT).show();
        }
        else {
            if (pass.equals("")){
                Toast.makeText(this, "Password must not be blank", Toast.LENGTH_SHORT).show();
            }
            else{
                if (pass.equals(pass2)){
                    if (ename == null){
                        realm = Realm.getDefaultInstance();
                        SharedPreferences info = getSharedPreferences("data", 0);
                        String welc = info.getString("UUIDS", "");
                        User newUser = realm.where(User.class).equalTo("uuid", welc).findFirst();

                        realm.beginTransaction();
                        newUser.setUsernames(user);
                        newUser.setPasswords(pass);
                        realm.commitTransaction();
                        try{
                            realm.beginTransaction();
                            realm.copyToRealmOrUpdate(newUser);
                            realm.commitTransaction();
                            finish();

                        }
                        catch(Exception e)
                        {
                            Toast t = Toast.makeText(this, "Error saving", Toast.LENGTH_LONG);
                            t.show();
                        }

                    }
                    else {Toast.makeText(this, "User already exists!", Toast.LENGTH_SHORT).show();}



                }
                else{
                    Toast.makeText(this, "Confirm password does not match", Toast.LENGTH_SHORT).show();
                }

            }

        }


    }
    @Click
    public void canceled(){finish();}
}
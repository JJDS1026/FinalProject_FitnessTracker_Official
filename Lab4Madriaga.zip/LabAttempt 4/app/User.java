public class User extends Real{
}

package madriaga.labs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.Click;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.annotations.ViewById;

import java.util.UUID;

import io.realm.Realm;
import io.realm.RealmResults;

@EActivity
public class Register extends AppCompatActivity {
    @ViewById
    EditText usernamereg;
    @ViewById
    EditText userpasswordreg;
    @ViewById
    EditText regpassconfirm;
    @ViewById
    Button savereg;
    @ViewById
    Button cancelreg;
    SharedPreferences info;
    String user, pass, pass2;
    Realm realm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }
    @AfterViews
    public void init()
    {
        realm = Realm.getDefaultInstance();

    }

    public void onDestroy() {
        super.onDestroy();

        if (!realm.isClosed()) {
            realm.close();
        }
    }


    @Click
    public void savereg()
    {
        String user = usernamereg.getText().toString();
        String pass = userpasswordreg.getText().toString();
        String pass2 = regpassconfirm.getText().toString();
        realm = Realm.getDefaultInstance();
        RealmResults<User> list = realm.where(User.class).findAll();
        //User list = realm.where(User.class).equalTo("Usernames,", )
        User ename =  realm.where(User.class).equalTo("usernames", usernamereg.getText().toString()).findFirst();


        if (user.equals("")) {
            Toast.makeText(this, "Name must not be blank", Toast.LENGTH_SHORT).show();
        }
        else {
            if (pass.equals("")){
                Toast.makeText(this, "Password must not be blank", Toast.LENGTH_SHORT).show();
            }
            else{
                if (pass.equals(pass2)){
                    if (ename == null){
                        /*info = getSharedPreferences("data", 0);
                    SharedPreferences.Editor editor = info.edit();
                    editor.putString("usernames",user);
                    editor.putString("passwords",pass);
                    editor.apply();
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
                    finish();*/
                        User newUser = new User();
                        newUser.setUuid(UUID.randomUUID().toString());
                        newUser.setUsernames(user);
                        newUser.setPasswords(pass);
                        long count = 0;
                        try{
                            realm.beginTransaction();
                            realm.copyToRealmOrUpdate(newUser);
                            realm.commitTransaction();

                            count = realm.where(User.class).count();
                            Toast t = Toast.makeText(this, "Saved: "+count, Toast.LENGTH_SHORT);
                            t.show();
                        }
                        catch(Exception e)
                        {
                            Toast t = Toast.makeText(this, "Error saving", Toast.LENGTH_LONG);
                            t.show();
                        }

                    }
                    else {Toast.makeText(this, "User already exists!", Toast.LENGTH_SHORT).show();}



                }
                else{
                    Toast.makeText(this, "Confirm password does not match", Toast.LENGTH_SHORT).show();
                }

            }

        }


    }
    @Click
    public void cancelreg(){finish();}


}